package sample04;

public class SungJukDelete implements SungJuk {

	public void execute() {
		

	}

}
