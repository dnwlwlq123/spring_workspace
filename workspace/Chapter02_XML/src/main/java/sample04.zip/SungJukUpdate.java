package sample04;


public class SungJukUpdate implements SungJuk {
	public void execute() {
		// TODO Auto-generated method stub
		
	}
	

}
