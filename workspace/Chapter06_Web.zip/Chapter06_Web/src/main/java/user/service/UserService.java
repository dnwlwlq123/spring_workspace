package user.service;

public interface UserService {

	public String isExistId(String id);

	

}
